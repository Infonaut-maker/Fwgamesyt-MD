const { getVar, setVar } = require('../../Plugin/configManager');

module.exports = {
    name: 'statusview',
    alias: ['statuslike', 'autoview', 'autolike'],
    desc: 'Toggle auto status view / like',
    category: 'Owner',
    ownerOnly: true,
    usage: '.statusview on/off  OR  .statuslike on/off',
    examples: ['.statusview on', '.statuslike off'],
    reactions: { start: '⚙️', success: '🐾', error: '😪' },

    execute: async (sock, m, { args, reply }) => {
        const cmd = (m.body || '').toLowerCase().split(/\s+/)[0].replace(/^[^a-z0-9]+/, '');
        const arg = args[0]?.toLowerCase();

        const settings = [
            { cmd: 'statusview', key: 'AUTO_STATUS_VIEW', label: 'Status View' },
            { cmd: 'autoview', key: 'AUTO_STATUS_VIEW', label: 'Status View' },
            { cmd: 'statuslike', key: 'AUTO_STATUS_LIKE', label: 'Status Like' },
            { cmd: 'autolike', key: 'AUTO_STATUS_LIKE', label: 'Status Like' }
        ];

        const setting = settings.find(s => s.cmd === cmd);
        if (!setting) return;

        if (!arg || !['on', 'off'].includes(arg)) {
            const current = getVar(setting.key, true);
            return reply(
                `ⓘ *${setting.label}:* ${current ? '✓ ON' : '⊘ OFF'}\n\n` +
                `� Usage: .${cmd} on/off`
            );
        }

        const value = arg === 'on';
        setVar(setting.key, value);
        await sock.sendMessage(m.chat, { react: { text: '✓', key: m.key } });
        return reply(`✓ *${setting.label}* → ${value ? 'ON' : 'OFF'}`);
    }
};
