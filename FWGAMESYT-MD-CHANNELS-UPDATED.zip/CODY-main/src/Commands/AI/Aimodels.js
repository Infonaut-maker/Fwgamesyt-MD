const axios = require('axios');

// FIX08-07-26: replaced the failing ai.crysnovax.link gateway with PREXZY.
const PREXZY = 'https://prexzyapis.com';
const MODELS_URL = `${PREXZY}/ai/aiwriter-models`;
const CHAT_URL = `${PREXZY}/ai/aiwriter-chat`;

// Default thumbnail for models (a generic AI/robot icon)
const DEFAULT_MODEL_THUMB = 'https://cdn-icons-png.flaticon.com/512/4616/4616735.png';

let modelCache = { data: null, expires: 0 };

async function fetchModels() {
    const now = Date.now();
    if (modelCache.data && modelCache.expires > now) return modelCache.data;

    try {
        const res = await axios.get(MODELS_URL, { timeout: 15000 });
        const data = res.data;
        let models = null;
        if (data?.result?.data && Array.isArray(data.result.data)) models = data.result.data;
        else if (Array.isArray(data?.result)) models = data.result;
        else if (data?.data && Array.isArray(data.data)) models = data.data;
        else if (data?.models && Array.isArray(data.models)) models = data.models;
        else if (typeof data?.result === 'string') {
            try {
                const parsed = JSON.parse(data.result);
                models = parsed?.data || parsed?.result || parsed?.models || parsed;
            } catch { models = null; }
        }
        if (!Array.isArray(models)) throw new Error('Invalid response structure');
        modelCache = { data: models, expires: now + 5 * 60 * 1000 };
        return models;
    } catch (err) {
        console.error('[AIWRITER] fetchModels error:', err.message);
        throw err;
    }
}

async function chatWithModel(prompt, modelCode) {
    const url = `${CHAT_URL}?prompt=${encodeURIComponent(prompt)}&model=${encodeURIComponent(modelCode || '')}`;
    const res = await axios.get(url, { timeout: 60000 });
    const data = res.data;

    let response = data?.message || data?.reply || data?.response || data?.result || data?.text;
    if (typeof response === 'object' && response !== null) {
        response = response.content || response.output || JSON.stringify(response, null, 2);
    }
    return typeof response === 'string' ? response.trim() : '';
}

module.exports = {
    name: 'aimodels',
    alias: ['aimodel', 'model'],
    desc: 'Browse AI models with carousel and chat with any model',
    category: 'AI',
    usage: '.aimodels\n.aimodels <number/code> <prompt>',

    execute: async (sock, m, { args, reply }) => {
        const input = args.join(' ').trim();

        if (!input) {
            try {
                await sock.sendMessage(m.chat, { react: { text: '🤖', key: m.key } });
                const models = await fetchModels();
                if (!Array.isArray(models) || models.length === 0) return reply('✘ No models available.');

                const cards = models.slice(0, 15).map((model, i) => {
                    const modelCode = model.code || '';
                    const commandExample = `.aimodel ${modelCode} Your prompt here`;
                    return {
                        image: { url: DEFAULT_MODEL_THUMB },
                        caption: `*${i+1}. ${model.name || 'Unknown'}*\n${model.is_pro ? '🜲 Pro' : '⌘ Free'}${model.is_image ? ' 🖼️' : ''}\n_${(model.description || '').slice(0, 100)}${model.description?.length > 100 ? '…' : ''}_`,
                        footer: `Code: ${modelCode}`,
                        nativeFlow: [{
                            text: '📋 Copy Command',
                            copy: commandExample
                        }, {
                            text: '📝 Copy Code',
                            copy: modelCode
                        }]
                    };
                });

                await sock.sendMessage(m.chat, {
                    text: `𓊈𝑽꯭𝑰꯭𝑷ࠡࠡࠡࠡࠢ𓊉 *AI MODEL SHOWCASE*`,
                    footer: `Swipe to browse ${models.length} models`,
                    cards: cards
                }, { quoted: m });

                await sock.sendMessage(m.chat, {
                    text: `_✨ How to use:_\n_Paste the copied command and replace "Your prompt here" with your question._`
                }, { quoted: m });

                await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            } catch (err) {
                console.error('[AIWRITER] List error:', err.message);
                reply(`✘ Failed to load models: ${err.message}`);
            }
            return;
        }

        // === CHAT WITH SELECTED MODEL ===
        const parts = input.split(' ');
        const firstPart = parts[0];
        const isNumber = /^\d+$/.test(firstPart);

        let selectedModel = null;
        let prompt = '';

        const models = await fetchModels();

        if (isNumber) {
            const index = parseInt(firstPart) - 1;
            if (!models || index < 0 || index >= models.length) {
                return reply(`✘ Invalid model number Choose 1–${models?.length || 0}.`);
            }
            selectedModel = models[index];
            prompt = parts.slice(1).join(' ').trim();
        } else {
            const searchTerm = firstPart.toLowerCase();
            selectedModel = models?.find(m =>
                m.name?.toLowerCase().includes(searchTerm) ||
                m.code?.toLowerCase().includes(searchTerm)
            );
            if (!selectedModel) {
                return reply(`✘ Model "${firstPart}" not found Use .aimodels to list models.`);
            }
            prompt = parts.slice(1).join(' ').trim();
        }

        if (!prompt) {
            return reply(`✘ Please provide a prompt\nExample: .aimodel ${firstPart} Hello world`);
        }

        try {
            await sock.sendMessage(m.chat, { react: { text: '💬', key: m.key } });

            const response = await chatWithModel(prompt, selectedModel.code);

            if (!response) {
                return reply('✘ Received an empty response.');
            }

            await sock.sendMessage(m.chat, {
                text: `𖣘 *${selectedModel.name}*\n\n${response}\n\n_⚉ PREXZY AI_`
            }, { quoted: m });

            await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } catch (err) {
            console.error('[AIWRITER CHAT]', err.message);
            reply(`✘ Failed to get response from ${selectedModel.name}.`);
        }
    }
};
